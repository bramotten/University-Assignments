/*
 * File: Hailstone.java ( java -cp .:acm.jar Hailstone )
 * --------------------
 * Problem set 1.4
 *
 * Bram Otten
 * 10992456
 * 
 * This program computes the hailstone  sequence.
 * Or, it checks if a number is wondrous.
 * Which it is if we ever reach 1 by performing n/2
 * on even numbers and 3n+1 on odd numbers.
 * n=27 takes 111 steps.
 * 
 */

import acm.program.*;

public class Hailstone extends ConsoleProgram {

	// it would not make much sense for this to not be 1
	// but it's easily changable now.
	private static final int SENTINEL = 1;
	
	public void run() {
		
		// intro and get a positive int as val
		println("This program computes Hailstone sequences.");
		int val = 0;
		int steps = 0;
		while (val <= 0) {
			val = readInt("Enter a positive number:  ");
		}
		
		// take steps until finished
		while (val != SENTINEL) {
			steps += 1;
			// the steps consist of these simple operations:
			// even numbers are halved
			if (val % 2 == 0) {
				val = val / 2;
				println((val * 2) + " is even, so I take half = " + val);
			} 
			// or odd numbers are multiplied by three and get one added
			// val must be an odd positive int at this point
			else {
				val = 3 * val + 1;
				println(((val - 1) / 3) + " is odd, so I make 3n+1 = " + val);
			}

		}
		
		println("It took " + steps + " steps to reach " + SENTINEL + ".");
		
	}
}
